
-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) NOT NULL,
  `request` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmfy2kagupkq5tdtq2o9gq2vb4` (`status_id`),
  KEY `FKel9kyl84ego2otj2accfd8mr7` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `request`, `status_id`, `user_id`, `date`) VALUES
(9, 'Мне нужна помощь', 4, 2, 5641654621),
(39, 'Мне нужна помощь', 3, 2, 567567567567564),
(82, 'Что-то написано', 2, 2, 1618417782900),
(85, 'Тест', 1, 2, 1618417910818);
