
-- --------------------------------------------------------

--
-- Структура таблицы `application_status`
--

DROP TABLE IF EXISTS `application_status`;
CREATE TABLE IF NOT EXISTS `application_status` (
  `id` bigint(20) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `application_status`
--

INSERT INTO `application_status` (`id`, `status`) VALUES
(1, 'Черновик'),
(2, 'Отправлено'),
(3, 'Принято'),
(4, 'Отклонено');
