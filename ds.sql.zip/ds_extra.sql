
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `FKel9kyl84ego2otj2accfd8mr7` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FKmfy2kagupkq5tdtq2o9gq2vb4` FOREIGN KEY (`status_id`) REFERENCES `application_status` (`id`);

--
-- Ограничения внешнего ключа таблицы `roles_user`
--
ALTER TABLE `roles_user`
  ADD CONSTRAINT `FK3ce7su39rh6dqgstm5pn0mlek` FOREIGN KEY (`rights_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `FKc37mjy035mdwv6q6t9241mv4q` FOREIGN KEY (`users_id`) REFERENCES `user` (`id`);
