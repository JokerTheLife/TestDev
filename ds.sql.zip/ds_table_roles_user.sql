
-- --------------------------------------------------------

--
-- Структура таблицы `roles_user`
--

DROP TABLE IF EXISTS `roles_user`;
CREATE TABLE IF NOT EXISTS `roles_user` (
  `id` bigint(20) NOT NULL,
  `rights_id` bigint(20) DEFAULT NULL,
  `users_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3ce7su39rh6dqgstm5pn0mlek` (`rights_id`),
  KEY `FKc37mjy035mdwv6q6t9241mv4q` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles_user`
--

INSERT INTO `roles_user` (`id`, `rights_id`, `users_id`) VALUES
(1, 3, 1),
(2, 2, 3),
(3, 1, 2),
(4, 3, 3);
